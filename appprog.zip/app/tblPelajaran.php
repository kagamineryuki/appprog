<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class tblPelajaran extends Model
{
    public $timestamps = false;
}
