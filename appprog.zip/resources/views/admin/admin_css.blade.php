<style>
    #contents-dashboard{
        height: 100vh;
    }

    #sidebar{
        height: 100vh;
        width: 30vw;
    }
</style>