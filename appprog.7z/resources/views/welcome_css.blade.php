<style>
    body{
        background: linear-gradient(rgba(11,4,87, .7), rgba(11,4,87, .7)), url('./images/pia22684.jpg') no-repeat center center fixed;
        -webkit-background-size: cover;
        -moz-background-size: cover;
        -o-background-size: cover;
        background-size: cover;
    }

    #welcome-bg{
        width: 100vw;
        height: 100vh;
    }
</style>