#Absensi QR Code berbasiskan Laravel

Program ini dipakai untuk menyelesaikan permasalahan absensi di sekolah yang masih manual dan memakan waktu banyak.

Dengan program ini absensi menjadi lebih cepat, mudah dan murah.